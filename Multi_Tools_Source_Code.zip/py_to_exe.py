import shutil

source_path = "main.py"
destination_path = "py to exe/main.py"

shutil.copy(source_path, destination_path)
